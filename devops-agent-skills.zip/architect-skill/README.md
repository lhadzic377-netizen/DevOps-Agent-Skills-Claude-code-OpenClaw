# DevOps Agent Skills

A comprehensive suite of AI agent skills that transforms Claude Code or OpenClaw from a code generator into a **full development team**.

## The Skill Family

| Skill | Trigger | Role |
|-------|---------|------|
| **Architect** | `/architect [topic]` | Chief Product Officer + Principal Engineer |
| **Planner** | `/plan [goal]` | Chief of Staff / Project Manager |
| **Designer** | `/design [feature]` | Principal Designer / Architect |
| **Builder** | `/build [feature]` | Senior Engineer / Craftsman |
| **Reviewer** | `/review [PR]` | Senior Reviewer / Quality Gatekeeper |
| **Tester** | `/test [feature]` | QA Engineer / Test Architect |
| **Fixer** | `/fix [issue]` | Senior SRE / Debugging Expert |
| **Risk Manager** | `/risk [plan]` | Risk Analyst / SRE Mindset |
| **Deployer** | `/deploy [target]` | DevOps Engineer / Release Manager |

## Workflow

```
┌─────────────┐
│  Architect  │ ← Strategic vision, system design
└──────┬──────┘
       ▼
┌─────────────┐
│   Planner   │ ← Task breakdown, sprint planning
└──────┬──────┘
       ▼
┌─────────────┐
│  Designer   │ ← API design, data models, schemas
└──────┬──────┘
       ▼
┌─────────────┐
│   Builder   │ ← Implementation, clean code
└──────┬──────┘
       ▼
┌─────────────┐
│  Reviewer   │ ← Code review, quality gates
└──────┬──────┘
       ▼
┌─────────────┐
│   Tester    │ ← Test strategy, TDD, coverage
└──────┬──────┘
       ▼
┌─────────────┐
│   Fixer     │ ← Debugging, root cause analysis
└──────┬──────┘
       ▼
┌─────────────┐
│  Deployer   │ ← CI/CD, deployment, rollback
└─────────────┘
```

---

## Installation

### Claude Code

```bash
# Copy all skills
cp -r claude-code/* ~/.claude/skills/

# Or individual skills
cp -r claude-code/architect ~/.claude/skills/
```

### OpenClaw

```bash
# Copy to your agent's skills directory
cp -r openclaw/* ~/.openclaw/agents/YOUR_AGENT/agent/skills/

# Example with betting-research agent:
cp -r openclaw/* ~/.openclaw/agents/betting-research/agent/skills/

# Restart gateway
openclaw gateway restart
```

---

## Usage

```
You: /architect betting research platform
AI: [Runs 4-Step Vision Loop]
    - Vision Statement + 3 KPIs
    - Conservative/Innovative/Moonshot comparison
    - Mermaid architecture diagram
    - Phased roadmap
AI: "Which approach should we prototype first?"

You: /plan MVP for conservative approach
AI: [Breaks down into sprint backlog]

You: /design user authentication API
AI: [Creates API specification]

You: /build user authentication
AI: [Implements from spec]

You: /review authentication implementation
AI: [Reviews code with BLOCK/WARN/SUGGEST]

You: /test authentication
AI: [Sets up test strategy with 80%+ coverage]

You: /fix login returning 500
AI: [Debugs systematically, finds root cause]

You: /deploy to production
AI: [Deploys with blue/green, rollback ready]
```

---

## Directory Structure

```
devops-agent-skills/
├── README.md
├── claude-code/          # Claude Code skills (YAML frontmatter)
│   ├── architect.md
│   ├── planner.md
│   ├── builder.md
│   ├── designer.md
│   ├── reviewer.md
│   ├── tester.md
│   ├── fixer.md
│   ├── risk-manager.md
│   └── deployer.md
└── openclaw/             # OpenClaw skills (markdown format)
    ├── architect.md
    ├── planner.md
    ├── builder.md
    ├── designer.md
    ├── reviewer.md
    ├── tester.md
    ├── fixer.md
    ├── risk-manager.md
    └── deployer.md
```

---

## Skill Descriptions

### Architect
Strategic thinking and system design. Creates high-level vision, compares approaches (Conservative/Innovative/Moonshot), designs architecture with Mermaid diagrams, and defines execution roadmaps.

### Planner
Task breakdown and sprint planning. Converts goals into actionable tasks, identifies dependencies, sequences work, and creates sprint backlogs.

### Designer
API, data model, and interface design. Creates schemas, defines REST endpoints, designs database structures, and specifies UI components.

### Builder
Implementation from specs. Writes clean, maintainable code following project conventions, with tests and proper error handling.

### Reviewer
Code review and quality assurance. Inspects PRs for correctness, security, performance, and maintainability. Rates issues BLOCK/WARN/SUGGEST/NIT.

### Tester
Test strategy and implementation. Sets up test pyramids, writes unit/integration/E2E tests, and ensures >80% coverage.

### Fixer
Debugging and problem resolution. Reproduces issues, finds root causes, implements fixes, and adds regression tests.

### Risk Manager
Risk identification and mitigation. Identifies technical/people/process/external risks, assesses likelihood and impact, and creates contingency plans.

### Deployer
Deployment and release management. Executes blue/green, canary, or direct deployments with rollback plans and post-deploy monitoring.

---

## Requirements

- **Claude Code:** Claude Code CLI
- **OpenClaw:** OpenClaw CLI with configured agent
- Mermaid.js support (for diagrams in compatible renderers)

## License

MIT
