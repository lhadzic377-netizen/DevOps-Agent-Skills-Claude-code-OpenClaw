# SKILL: Error Archivist

## Usage
Logs mistakes, failures, and anti-patterns. Creates institutional memory.

## What Gets Archived

### Errors Made
- Factual mistakes
- Logic errors
- Syntax errors
- Misunderstanding of requirements
- Missed edge cases

### Failures
- Approaches that didn't work
- Tasks that took too long
- Over-engineered solutions
- Under-engineered solutions
- Wrong assumptions

### Anti-Patterns Discovered
- What not to do in this codebase
- Known bad patterns
- Common mistakes in domain
- Deprecated approaches

## Archive Structure

```
~/.claude/memory/errors/
├── YYYY-MM-DD/
│   ├── error.md
│   ├── failure.md
│   └── anti-pattern.md
├── by-type/
│   ├── logic-errors/
│   ├── fact-errors/
│   ├── approach-failures/
│   └── anti-patterns/
├── by-project/
│   └── [project-name]/
└── summary.md
```

## Error Template

```markdown
# Error: [Brief Title]

**Date:** YYYY-MM-DD
**Severity:** Low / Medium / High / Critical
**Project:** [project or "general"]
**Task:** [what I was trying to do]

## What Happened
[Description of the error]

## Root Cause
[Why it happened]
[What I misunderstood or missed]

## How I Found It
[How the error was caught]
[What revealed the mistake]

## Correction
[How I fixed it]

## Prevention
- [ ] Don't do [this]
- [ ] Always check [that]
- [ ] Verify [assumption]

## Tags
#error #type #project #domain

---
*Filed by Error Archivist*
```

## Failure Template

```markdown
# Failure: [Brief Title]

**Date:** YYYY-MM-DD
**Project:** [project or "general"]
**Approach:** [what I tried]

## What I Tried
[Approach taken]

## Why It Failed
[Specific reasons]

## Lessons Learned
1. [Lesson 1]
2. [Lesson 2]
3. [Lesson 3]

## What Worked Instead
[Alternative that succeeded]

## Don't Do This
[Clear anti-pattern statement]

---
*Filed by Error Archivist*
```

## Anti-Pattern Template

```markdown
# Anti-Pattern: [Name]

**Discovered:** YYYY-MM-DD
**Project:** [where found]
**Severity:** Warning / Danger / Critical

## The Problem
[What's wrong with this approach]

## When It Applies
[Situations where this is bad]

## Symptoms
[How to recognize when in this pattern]

## Why It's Bad
[Consequences, downsides]

## Correct Approach
[What to do instead]

## Examples
### Bad
\`\`\`
[bad code]
\`\`\`

### Good
\`\`\`
[good code]
\`\`\`

---
*Filed by Error Archivist*
```

## How to Use Archives

Before risky task:
```bash
# Check for known errors
grep -r "similar situation" ~/.claude/memory/errors/

# Check for anti-patterns
cat ~/.claude/memory/errors/anti-patterns/*.md | head -20
```

## Trigger Sources
- Self-detected during review
- User correction ("No, that's wrong")
- Task failure
- Debug session
- Post-mortem

## Constraints
- Be specific, not vague
- Include actionable prevention
- Categorize correctly
- Update summary monthly
- Review anti-patterns quarterly
