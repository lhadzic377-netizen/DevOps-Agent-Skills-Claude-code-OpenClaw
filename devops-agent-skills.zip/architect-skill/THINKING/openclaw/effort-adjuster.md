# SKILL: Effort Adjuster

## Usage
Scales effort based on task complexity. Avoids over-engineering simple tasks.

## Trigger
Automatic - applies to every task.

## Effort Levels

| Level | When to Use | Example |
|-------|-------------|---------|
| **XS** | 30 seconds | Fix typo, answer simple question |
| **S** | 5 minutes | Simple function, one file edit |
| **M** | 30 minutes | Small feature, typical bug fix |
| **L** | 2 hours | Significant feature, code review |
| **XL** | Full day+ | Complex feature, architecture |
| **XXL** | Multi-day | Major project, system design |

## Effort Detection

### XS (Trivial)
- Single word/sentence response
- Clearly defined answer
- No code needed
- One file, few lines

### S (Simple)
- Simple function/class
- Well-understood domain
- Clear requirements
- < 1 hour typical

### M (Moderate)
- New feature with spec
- Non-trivial bug
- Multiple files
- Tests needed

### L (Large)
- Complex feature
- Multiple components
- API design involved
- Significant testing

### XL (Major)
- System-wide change
- New architecture
- Migration
- Complex coordination

### XXL (Huge)
- New system
- Multi-team effort
- Long timeline
- High risk

## Effort Calibration

```markdown
## Effort: [Level]

### Task Complexity: [1-5]
### Code Scope: [Lines/files estimate]
### Requirements: [Clear/vague]
### Testing: [Simple/complex]
### Dependencies: [Few/many]
### Risk: [Low/Med/High]

### Reasoning
[Why this effort level]

### Adjusted Level
[Final decision after considering factors]
```

## Effort Capping

**Rules:**
- If user says "quick fix" → cap at S
- If user says "simple" → cap at M
- If complexity unclear → ask or start S, scale up
- If task grows beyond cap → stop and report

## Auto-Scaling

```
Initial assessment: M
↓
Task grows: "this is more complex"
↓
Reassess: L
↓
This is getting bigger
↓
Stop: "This has grown from M to XL. Should I continue?"
```

## Speed vs Quality

| Task | Speed | Quality Checkpoints |
|------|-------|---------------------|
| XS-S | Fast, minimal iteration | User confirms |
| M | Normal pace | Test, review |
| L | Careful, checkpoints | Multiple reviews |
| XL+ | Gradual, validated stages | Phase gate reviews |

## Output
Internal calibration. Reports level if asked.

## Constraints
- Start lower, scale up - never over-engineer
- Ask if unclear constraint
- Respect "quick" requests
- Don't slow down trivial tasks
- Don't rush complex tasks
