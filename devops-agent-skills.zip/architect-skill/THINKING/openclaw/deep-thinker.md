# SKILL: Deep Thinker

## Usage
Applies first-principles reasoning to complex problems. Think through difficult problems systematically.

## Trigger
- `/think [problem]` - Apply deep thinking
- `/analyze [situation]` - Deep analysis
- When facing non-obvious solution
- When stuck on problem
- When conventional approaches fail

## First Principles Framework

### Step 1: DECONSTRUCT

Break problem into fundamental truths:
- What do we KNOW is true?
- What do we ASSUME is true?
- What do we NOT know?

### Step 2: CHALLENGE ASSUMPTIONS

For each assumption, ask:
- Is this really true?
- What if the opposite is true?
- What evidence supports this?
- Has this assumption ever failed?

### Step 3: REBUILD FROM TRUTH

Start with facts, build reasoning:
```
FACT 1 + FACT 2 → INSIGHT A
INSIGHT A + FACT 3 → INSIGHT B
...
SOLUTION
```

### Step 4: PROVE WRONG TEST

Try to disprove your reasoning:
- What evidence would falsify this?
- Find the weakest point
- Strengthen or abandon

## Thinking Template

```markdown
# Deep Thought: [Problem]

**Started:** YYYY-MM-DD HH:MM
**Complexity:** High / Very High

## The Problem
[Restate in simplest terms]

## What We Know (Facts)
1. [Fact 1]
2. [Fact 2]
3. [Fact 3]

## Assumptions (Need to Verify)
1. [Assumption] → [What would prove false]
2. [Assumption] → [What would prove false]

## Deconstruction
[Breaking problem into parts]

## Reasoning Chain
```
[FACT] + [FACT] = [INSIGHT]
[INSIGHT] + [FACT] = [NEXT INSIGHT]
...
```

## Weaknesses in Reasoning
[Where might this fall apart?]

## Conclusion
[What we believe to be true]

## What Would Change Our Mind
[Test conditions]
```

## When to Use

**High value:**
- Strategic decisions
- Architecture choices
- Unfamiliar problem domains
- After failed conventional approaches
- Root cause of persistent problems

**Lower value:**
- Simple questions
- Routine tasks
- Well-understood domains
- Time-pressured situations

## Constraints
- Use when complexity warrants
- Time-box to 10 minutes max
- Document reasoning for others
- Challenge own assumptions first
- Consider experts vs generalist view
