# SKILL: Decision Maker

## Usage
Structured framework for making decisions. Evaluates options with clarity.

## Trigger
- `/decide [question]` - Make a decision
- `/compare [option1] vs [option2]` - Compare
- When facing multiple options
- When uncertain what to do
- Before committing to approach

## Decision Framework

### Step 1: FRAME THE DECISION

**Define clearly:**
- What exactly needs to be decided?
- When does it need to be decided?
- Who decides if there's disagreement?
- What constraints exist?

**Output:**
```
## Decision Statement

We need to decide: [what]
By: [deadline]
Decision maker: [who]
Constraints: [limits]
```

### Step 2: IDENTIFY OPTIONS

**Options Checklist:**
- [ ] Option A: [description]
- [ ] Option B: [description]
- [ ] Option C: [do nothing / another approach]
- [ ] ...

**Rule:** Always include "do nothing" as baseline.

### Step 3: EVALUATE CRITERIA

**Common Criteria:**
| Criteria | Weight |
|----------|--------|
| Cost (time/money) | High/Med/Low |
| Risk | High/Med/Low |
| Benefit | High/Med/Low |
| Reversibility | Easy/Hard |
| Time to value | Fast/Slow |

### Step 4: PROS & CONS

For each option:
```
## Option A: [Name]

### Pros
- [Benefit 1]
- [Benefit 2]

### Cons
- [Drawback 1]
- [Drawback 2]

### Risk if wrong
[What happens if this turns out bad]
```

### Step 5: COMPARE

```markdown
## Comparison Matrix

| Criteria | Weight | Option A | Option B | Option C |
|----------|--------|----------|----------|----------|
| Cost | 20% | 3/5 | 4/5 | 5/5 |
| Risk | 30% | 2/5 | 4/5 | 3/5 |
| Benefit | 30% | 4/5 | 3/5 | 2/5 |
| Reversibility | 20% | 3/5 | 4/5 | 5/5 |
| **Total** | 100% | **2.9** | **3.8** | **3.5** |
```

### Step 6: DECIDE

**Decision Rule:**
- Choose highest score if clear winner
- Choose simplest if scores close
- Escalate if can't decide
- Delay if missing critical info

### Step 7: VALIDATE

```
## Validation

### What we decided: [option]
### Expected outcome: [what happens next]
### How we'll know if wrong: [metrics]
### Fallback if wrong: [what to do]
```

## Decision Types

| Type | Approach |
|------|----------|
| Reversible | Favor speed, can undo |
| Irreversible | Favor caution, more analysis |
| High stakes | More analysis, more people |
| Low stakes | Quick decision OK |

## Constraints
- Never decide without clear question
- Always compare 2+ real options
- Include "do nothing" baseline
- Document reasoning
- Set review date for big decisions
