# SKILL: Security Sense

## Usage
Automatically flags security concerns. Prevents security issues before they happen.

## When It Triggers
- Writing authentication/authorization code
- Handling user input
- Database queries
- File operations
- API endpoints
- Password/secret handling
- User data processing

## Security Checklist

### Authentication
```
□ Passwords hashed (bcrypt/argon2)
□ Tokens properly validated
□ Session management secure
□ No hardcoded credentials
□ Proper logout handling
```

### Authorization
```
□ Users can only access own data
□ Admin routes protected
□ Role checks before actions
□ Resource ownership verified
□ Principle of least privilege
```

### Input Validation
```
□ All user input sanitized
□ SQL parameterized queries
□ No eval() or dynamic code
□ File paths validated
□ URLs sanitized
```

### Data Handling
```
□ Sensitive data encrypted
□ PII properly protected
□ Logs don't contain secrets
□ Data retention policies
□ Secure defaults
```

### Output
```
□ No sensitive data leaked
□ Error messages generic
□ Headers set properly
□ HTTPS enforced
```

## Security Flags

### CRITICAL (Block and fix)
- Hardcoded password/secret
- SQL injection possible
- Missing auth on protected route
- Encryption bypass
- Data exfiltration risk

### HIGH (Warn and require)
- Weak password hashing
- Session fixation possible
- CSRF possible
- Unvalidated redirects

### MEDIUM (Suggest fix)
- Missing rate limiting
- Cache sensitive data
- Verbose errors in prod
- Missing security headers

### LOW (Nice to improve)
- Use HTTPS only
- Add security headers
- Enable HSTS
- Use secure cookies

## Security Review Template

```markdown
## Security Review

### Input Validation: [Pass/Fail]
### Authentication: [Pass/Fail]
### Authorization: [Pass/Fail]
### Data Protection: [Pass/Fail]
### Error Handling: [Pass/Fail]

### Issues Found
| Severity | Issue | Location | Fix |
|----------|-------|----------|-----|
| CRITICAL | [Issue] | [file:line] | [Fix] |

### Recommendations
1. [Suggestion]
```

## Common Vulnerabilities

### OWASP Top 10
1. Injection
2. Broken Auth
3. Sensitive Data Exposure
4. XML External Entities
5. Broken Access Control
6. Security Misconfiguration
7. XSS
8. Insecure Deserialization
9. Using Components with Vulnerabilities
10. Insufficient Logging

## Safe Patterns

### SQL Injection Prevention
```sql
-- BAD
"SELECT * FROM users WHERE id = " + userId

-- GOOD
"SELECT * FROM users WHERE id = ?"
```

### Password Hashing
```javascript
// BAD
hash(password, 'md5')

// GOOD
bcrypt.hash(password, 12)
```

### Input Validation
```javascript
// BAD
eval(userInput)

// GOOD
const validated = schema.parse(userInput)
```

## Constraints
- Flag issues before implementation
- Never implement known insecure pattern
- Ask if security unclear
- Prioritize user data protection
- When in doubt, error on secure side
