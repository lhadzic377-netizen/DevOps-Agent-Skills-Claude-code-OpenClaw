# SKILL: Research Navigator

## Usage
Efficient web search, documentation lookup, and fact verification.

## Trigger
- `/research [topic]` - Research topic
- `/search [query]` - Quick search
- `/lookup [term]` - Documentation lookup
- `/verify [claim]` - Verify fact
- `/docs [library]` - Get docs

## Research Workflow

### Step 1: CLARIFY RESEARCH GOAL

**Ask:**
- What specifically do we need to know?
- Why do we need this?
- What format answer is most useful?
- How current does this need to be?

### Step 2: IDENTIFY SOURCES

**Source Priority:**
1. Official documentation
2. Academic papers
3. Authoritative guides
4. Well-vetted blog posts
5. Community knowledge

**Avoid:**
- Unverified blogs
- Outdated info
- Social media
- Random tutorials

### Step 3: SEARCH STRATEGY

```bash
# Official docs first
site:docs.example.com [topic]

# Specific library
[library name] [topic] documentation

# Academic
site:arxiv.org [topic]

# Quality blog
[topic] best practices guide
```

### Step 4: VERIFY & SYNTHESIZE

**Verify claims:**
- Cross-reference multiple sources
- Check publication date
- Note consensus vs debate
- Flag uncertain information

**Synthesize:**
- Combine insights
- Note contradictions
- Prioritize actionable info
- Cite sources

## Research Output Template

```markdown
# Research: [Topic]

**Researched:** YYYY-MM-DD
**Confidence:** High / Medium / Low
**Sources:** N verified, N total

## Executive Summary
[1-2 sentence answer to the question]

## Key Findings
1. [Finding with citation]
2. [Finding with citation]
3. [Finding with citation]

## Details
[Expanded information]

## Source Quality
| Source | Reliability | Date | Key Info |
|--------|-------------|------|----------|
| [source] | High | YYYY | [info] |

## Contradictions
[Any conflicting info found]

## Actionable Recommendations
1. [Recommendation]
2. [Recommendation]

## What We Don't Know
[Remaining gaps]

## Sources
- [Source 1](url)
- [Source 2](url)
```

## Quick Lookup Format

When just verifying a fact:
```
**Question:** [what user asked]
**Answer:** [direct answer]

**Confidence:** [High/Med/Low]
**Source:** [source link]
**Date checked:** YYYY-MM-DD
```

## Search Tips

### Finding Best Practices
```
"[technology]" best practices 2024
"[problem]" solution guide
"[library]" patterns
```

### Finding Troubleshooting
```
"[error message]" fix
"[tool]" troubleshooting
"[library]" common issues
```

### Finding Comparisons
```
"[A] vs [B]" comparison
"[technology]" alternatives
```

## Constraints
- Always cite sources
- Note confidence level
- Flag outdated information
- Distinguish fact from opinion
- Don't make up information
- Verify before stating as fact
- Search efficiency: 5 min max for simple, 15 min for deep
