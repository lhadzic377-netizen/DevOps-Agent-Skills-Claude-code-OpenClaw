# SKILL: Performance Radar

## Usage
Detects performance anti-patterns before they cause issues.

## When It Triggers
- Writing database queries
- Loops and iterations
- API endpoints
- File operations
- Memory allocations
- Network calls

## Performance Checklist

### Database
```
□ Query complexity (N+1?)
□ Missing indexes on WHERE/JOIN
□ SELECT * when limited columns
□ Unbounded result sets
□ No pagination
```

### Loops
```
□ Nested loops (O(n²))
□ Work in loops that could be vectorized
□ Unnecessary iterations
□ Early exit not used
□ Cache-friendly access patterns
```

### Memory
```
□ Unbounded arrays/lists
□ Memory leaks
□ Large object allocations in loops
□ String concatenation in loops
□ Missing stream processing
```

### Network
```
□ Synchronous calls blocking
□ Missing batching
□ No caching
□ Retry storms
□ Chatty APIs
```

### Async
```
□ Blocking in async code
□ Unnecessary awaits
□ Missing parallelism
□ Promise chains instead of Promise.all
```

## Performance Flags

### CRITICAL (Fix before merge)
- N+1 query loops
- Memory leak
- Unbounded allocation
- Blocking main thread

### HIGH (Optimize soon)
- Missing database index
- Inefficient algorithm (O(n²) worse)
- No pagination
- Synchronous in hot path

### MEDIUM (Consider improving)
- Redundant API calls
- No caching on expensive ops
- String concatenation in loop
- Missing compression

### LOW (Nice to have)
- Enable gzip
- HTTP/2 multiplexing
- Resource hints (preload)
- Lazy loading

## Performance Review Template

```markdown
## Performance Review

### Database: [Pass/Optimize/Critical]
### Algorithm: [Pass/Optimize/Critical]
### Memory: [Pass/Optimize/Critical]
### Network: [Pass/Optimize/Critical]

### Issues Found
| Severity | Issue | Location | Impact |
|----------|-------|----------|--------|
| HIGH | N+1 query | file:42 | 1000 queries instead of 2 |

### Estimates
- Current: [X ms / X MB]
- With fix: [Y ms / Y MB]
- Improvement: Z%
```

## Common Fixes

### N+1 Query
```javascript
// BAD: N+1
for (const user of users) {
  user.posts = db.query('SELECT * FROM posts WHERE user_id = ?', user.id)
}

// GOOD: Join or batch
const userIds = users.map(u => u.id)
user.posts = db.query('SELECT * FROM posts WHERE user_id IN (?)', userIds)
```

### Missing Index
```sql
-- BAD: Full table scan
SELECT * FROM orders WHERE user_id = 123 AND status = 'pending'

-- GOOD: Composite index
CREATE INDEX idx_orders_user_status ON orders(user_id, status)
```

### Unbounded Result
```javascript
// BAD: All results
const users = db.query('SELECT * FROM users')

// GOOD: Paginate
const users = db.query('SELECT * FROM users LIMIT 100 OFFSET 0')
```

## Performance Budget
- API response: < 200ms (p95)
- Page load: < 2s
- DB query: < 50ms
- Memory per request: < 100MB

## Constraints
- Don't optimize prematurely
- Measure before fixing
- Optimize hot paths first
- Consider readability tradeoffs
- Document performance decisions
