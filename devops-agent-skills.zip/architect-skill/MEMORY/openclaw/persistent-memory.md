# SKILL: Persistent Memory

## Usage
Stores and retrieves learnings across sessions. Enables continuous improvement.

## What Gets Remembered

### Learnings (auto-captured)
- Errors and how they were fixed
- User corrections ("No, that's wrong...")
- Discovered better approaches
- API quirks or behaviors

### Decisions (captured when made)
- Why a particular approach was chosen
- Trade-offs considered
- Rejected alternatives

### Discoveries (captured when found)
- Useful tools or techniques
- Project-specific patterns
- Performance insights

## Memory Structure

```
~/.claude/memory/
├── learnings/
│   ├── YYYY-MM-DD_learning.md
│   └── ...
├── decisions/
│   ├── YYYY-MM-DD_decision.md
│   └── ...
├── discoveries/
│   ├── YYYY-MM-DD_discovery.md
│   └── ...
└── context/
    └── current.md
```

## When to Save

**Auto-trigger:**
- User says "No, that's wrong" or "Actually..."
- Error that took long to fix
- Better approach discovered for recurring task
- External API or tool fails
- Realization about outdated knowledge

**Manual trigger:**
- User says "Remember that..."
- User corrects you
- You discover something worth saving

## Memory Format

```markdown
# Learning: [Brief Title]

**Date:** YYYY-MM-DD
**Context:** [When this happened]
**What happened:** [The issue/situation]
**Resolution:** [How it was fixed/handled]
**Apply when:** [When to use this knowledge]

---
```

## How to Retrieve

Before significant tasks, check relevant memories:
```bash
# Search memories
grep -r "keyword" ~/.claude/memory/learnings/

# Recent learnings
ls -t ~/.claude/memory/learnings/ | head -5
```

## Output
When finding relevant memory: "I recall we learned that [brief summary]. Applying it now."

## Constraints
- Save atomic facts, not entire conversations
- Include date for recency
- Use search-friendly keywords
- Don't overwrite - append new learnings
