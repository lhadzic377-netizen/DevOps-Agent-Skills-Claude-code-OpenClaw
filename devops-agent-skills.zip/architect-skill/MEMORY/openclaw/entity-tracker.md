# SKILL: Entity Tracker

## Usage
Tracks persistent entities across sessions: people, projects, decisions, and their relationships.

## What Gets Tracked

### People
- Names and roles
- Contact info (if provided)
- Expertise areas
- Preferences and communication style
- Projects worked on together

### Projects
- Name and purpose
- Current status
- Key files and structure
- Active issues
- Decisions made
- People involved

### Decisions
- What was decided
- Why that approach was chosen
- Alternatives considered
- Date made
- Who approved
- Implications

## Entity Files

```
~/.claude/memory/entities/
├── people/
│   ├── [name].md
│   └── ...
├── projects/
│   ├── [project-name].md
│   └── ...
└── decisions/
    ├── [project-name]/
    │   └── YYYY-MM-DD_decision.md
    └── ...
```

## Person Template

```markdown
# Person: [Name]

**Role:** [job title / relationship]
**Since:** [when first met]

## Details
[Background, context]

## Expertise
- [Skill 1]
- [Skill 2]

## Preferences
- Communication: [how they like to communicate]
- Technical: [technical preferences]
- Workflow: [how they like to work]

## Projects
- [[project-name]] - [role]
- [[project-name]] - [role]

## Notes
[Other relevant info]

---
*Last updated: YYYY-MM-DD*
```

## Project Template

```markdown
# Project: [Name]

**Status:** [active/completed/on-hold]
**Started:** YYYY-MM-DD
**Purpose:** [what this project is for]

## Overview
[Description]

## Structure
[Key files and directories]

## Team
- [[person-name]] - [role]
- [[person-name]] - [role]

## Key Decisions
- [[decision-link]] - [brief]
- [[decision-link]] - [brief]

## Current Focus
[What's being worked on now]

## Issues
- [active issue 1]
- [active issue 2]

---
*Last updated: YYYY-MM-DD*
```

## Decision Template

```markdown
# Decision: [Brief Title]

**Project:** [[project-name]]
**Date:** YYYY-MM-DD
**Status:** [proposed/approved/overturned]

## Decision
[What was decided]

## Rationale
[Why this approach was chosen]

## Alternatives Considered
- [Alternative 1] - [why rejected]
- [Alternative 2] - [why rejected]

## Approvers
- [[person-name]]
- [[person-name]]

## Implications
[What this affects]

## Status History
- YYYY-MM-DD: [event]

---
*Last updated: YYYY-MM-DD*
```

## Constraints
- Update on each interaction
- Link related entities
- Keep current with recent info
- Don't invent info - record only what user provides
