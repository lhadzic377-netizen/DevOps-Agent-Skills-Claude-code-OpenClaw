# SKILL: Knowledge Librarian

## Usage
Files important conversation insights into organized, searchable knowledge base.

## When to File

**Auto-trigger:**
- Key decision made
- Solution found to complex problem
- Technical approach agreed upon
- Project structure established
- User explains something important about project

**Manual trigger:**
- User says "File this under..."
- After significant problem solved
- End of productive session

## Knowledge Categories

```
~/.claude/memory/knowledge/
├── [project-name]/
│   ├── decisions/
│   ├── patterns/
│   ├── architecture/
│   └── user-preferences/
├── [project-name]/
│   └── ...
└── general/
    ├── tools/
    ├── techniques/
    └── reference/
```

## Filing Format

```markdown
# [Category]: [Brief Title]

**Project:** [project-name]
**Date:** YYYY-MM-DD
**Source:** [session context or user directive]

## Summary
[1-3 sentence summary of what was discussed/decided]

## Key Points
- [Point 1]
- [Point 2]
- [Point 3]

## Details
[Full context, code snippets, links, etc.]

## Related
- [[link to related knowledge]]
- [[tags: tag1, tag2]]

---
*Filed by Knowledge Librarian*
```

## Search & Retrieve

```bash
# Find by keyword
grep -r "search term" ~/.claude/memory/knowledge/

# Find by project
ls ~/.claude/memory/knowledge/[project]/

# Find by tag
grep -r "tag:" ~/.claude/memory/knowledge/
```

## Auto-Tagging
Add tags for easy retrieval:
- Project name
- Technology (python, react, etc.)
- Type (decision, pattern, setup)
- Status (active, deprecated)

## Output
When filing: "Filed under [category]: [brief summary]"

## Constraints
- One idea per file
- Use consistent naming
- Include enough context to be useful later
- Tag generously for search
