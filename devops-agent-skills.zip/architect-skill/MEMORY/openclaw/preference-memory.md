# SKILL: Preference Memory

## Usage
Remembers and applies user preferences for communication, workflow, and technical approach.

## What Gets Remembered

### Communication
- How formal/casual
- Preferred explanation depth
- Tone (direct vs diplomatic)
- Feedback style preferred
- Questions to ask vs figure out solo

### Workflow
- When to ask vs proceed
- Preferred file org
- Git commit style
- Review preferences
- How much detail before starting

### Technical
- Preferred language/framework
- Code style preferences
- Architecture preferences
- Testing philosophy
- Performance vs simplicity tradeoff

### Project-Specific
- Domain knowledge level
- Industry terminology
- Stakeholders to consider
- Compliance requirements

## Storage

```
~/.claude/memory/preferences/
├── communication.md
├── workflow.md
├── technical.md
├── [project-name].md
└── summary.md          # Quick reference
```

## Master Preference File

```markdown
# User Preferences Summary

**Last updated:** YYYY-MM-DD
**Collected over:** N sessions

## Communication Style
- Formality: [1-5 scale]
- Explanation depth: [brief/moderate/detailed]
- Tone: [direct/casual/diplomatic]
- Ask before: [when to ask vs proceed]

## Workflow
- Commit style: [conventional/other]
- File org: [preferred structure]
- Review: [what to check]
- Starting: [info needed before]

## Technical Defaults
- Language: [preferred]
- Framework: [preferred]
- Testing: [philosophy]
- Architecture: [preference]

## Project Context
[Current project specifics]

## Notes
[Anything else important]

---
*Update when user corrects or clarifies preferences*
```

## How to Use

**At session start:**
1. Read summary.md
2. Apply preferences silently
3. If preferences missing, ask or observe

**When user corrects:**
1. Save correction to preferences
2. Acknowledge briefly
3. Apply going forward

## Output
When applying preference: silent (internal only)

## Constraints
- Don't announce preferences back to user
- Observe and update naturally
- Ask if unclear and important
- Respect privacy - don't store sensitive info
