# SKILL: Self-Monitor

## Usage
Watches for issues during autonomous operation and triggers self-correction.

## When It Runs
Always active during autonomous operations.

## What It Monitors

### Health Checks
- Memory usage
- API rate limits
- Network connectivity
- Processing time
- Error rates

### Quality Gates
- Output quality (is it making sense?)
- Action success rate
- Loop detection (repeating same action)
- Progress toward goal

### External Signals
- User reactions (corrections, frustration)
- System errors
- Resource exhaustion

## Monitoring Template

```markdown
## Health Check: HH:MM:SS

**Uptime:** Xm
**Actions:** N (S:F = X:X)
**Errors:** N
**Rate Limit:** N% remaining
**Memory:** XX%

## Recent Actions
[Last 5 actions and outcomes]

## Issues Detected
- None
- OR
- [Issue 1]: [severity]
- [Issue 2]: [severity]

## Self-Correction Actions
- None needed
- OR
- [Action taken]
```

## Issue Severity

| Level | Meaning | Action |
|-------|---------|--------|
| LOW | Minor inefficiency | Note, continue |
| MEDIUM | Potential problem | Adjust approach |
| HIGH | Likely to fail | Pause, fix |
| CRITICAL | Will fail/crash | Stop, alert |

## Self-Correction Actions

### LOW (Log and continue)
```python
if issue == "slow_processing":
    log("Processing slower than optimal")
    continue
```

### MEDIUM (Adjust)
```python
if issue == "high_error_rate":
    log("Error rate elevated, adding verification")
    add_extra_checks()
    continue
```

### HIGH (Pause and fix)
```python
if issue == "rate_limit_approaching":
    log("Rate limit near, pausing to cool down")
    sleep(60)
    continue
```

### CRITICAL (Stop and alert)
```python
if issue == "unrecoverable_error":
    log("CRITICAL: Cannot continue")
    stop_autonomous()
    alert_user("Issue requires attention")
```

## Loop Detection

Detect repeating actions:
```python
recent_actions = get_last_n(5)
if all_same_action(recent_actions):
    if attempts >= 3:
        stop_and_report("Loop detected: [action]")
    else:
        backoff_and_retry()
```

## Logging

```bash
~/.claude/memory/self-monitor/
├── health/
│   └── YYYY-MM-DD.md
├── corrections/
│   └── YYYY-MM-DD.md
└── incidents/
    └── YYYY-MM-DD_HHMMSS.md
```

## Output
Silent monitoring. Reports only when intervention needed or summary at end.

## Constraints
- Don't block on monitoring
- Max 5% CPU for monitoring
- Keep history for debugging
- Always allow manual override
- Log everything for post-mortem
