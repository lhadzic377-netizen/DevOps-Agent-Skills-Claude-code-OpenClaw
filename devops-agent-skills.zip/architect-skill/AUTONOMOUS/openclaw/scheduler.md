# SKILL: Scheduler

## Usage
Schedules and executes time-based tasks. Handles recurring jobs and one-shot reminders.

## Trigger
- `/schedule [time] [task]` - Schedule one-shot
- `/cron [expression] [task]` - Set up recurring
- `/tasks` - List scheduled tasks
- `/cancel [task-id]` - Cancel scheduled task

## Time Formats

```
+5m     - 5 minutes from now
+2h     - 2 hours from now
+1d     - 1 day from now
09:30   - Today at 09:30 (or tomorrow if past)
09:30 tomorrow - Explicit
2024-12-25 09:00 - Specific date
every 5m - Every 5 minutes (cron)
every 1h - Every hour (cron)
every day 09:00 - Daily at 9am
every week monday 09:00 - Weekly Monday
```

## Task Format

```markdown
## Scheduled Task: [unique-id]

**Type:** one-shot | recurring
**Schedule:** [time/cron]
**Created:** YYYY-MM-DD HH:MM
**Status:** pending | running | completed | failed | cancelled

## Task
[What to do]

## Context
[Why this was scheduled]
[How to verify completion]

## Execution Log
- YYYY-MM-DD HH:MM: Executed
- YYYY-MM-DD HH:MM: Success
- YYYY-MM-DD HH:MM: Failed - [reason]

## Result
[What happened]

---
```

## Storage

```
~/.claude/memory/scheduler/
├── tasks/
│   ├── [uuid].md
│   └── ...
└── logs/
    ├── YYYY-MM-DD.md
    └── ...
```

## Execution

### One-Shot
1. Wait until scheduled time
2. Load context (current project, preferences)
3. Execute task
4. Log result
5. Notify user if configured

### Recurring
1. Run at schedule
2. Check if still relevant (context)
3. Execute if relevant
4. Skip if not relevant (log reason)
5. Continue schedule

## Notification

After execution:
- Success: Brief confirmation
- Failure: What failed + retry info
- Skip: Log reason only

## Constraints
- Don't run missed tasks on catch-up
- Max 100 scheduled tasks
- Recurring tasks max 24hr interval
- One-shot tasks max 30 days out
- Always verify before executing
- Never execute without context check

## Error Handling
- Task fails → Log error + retry if recurring
- Max 3 retries, then mark failed
- System restart → Reschedule active recurring
