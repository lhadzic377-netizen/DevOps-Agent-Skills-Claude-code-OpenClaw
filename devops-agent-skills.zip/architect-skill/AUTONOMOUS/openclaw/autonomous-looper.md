# SKILL: Autonomous Looper

## Usage
Runs continuous autonomous operation with self-checking and self-correction.

## Trigger
- `/autonomous [task]` - Start autonomous loop
- `/loop [interval] [task]` - Run with interval
- `/stop` - Stop autonomous mode

## How It Works

```
START → CHECK → ACT → VERIFY → (LOOP) → CHECK → ...
         ↓
      PROBLEM? → FIX or ESCALATE
```

## Loop Structure

### 1. CHECK (Before each action)
- Is task still relevant?
- Any new user requests?
- Environment changed?
- Resources available?

### 2. ACT (Execute)
- Perform single atomic action
- Log action taken
- Note expected outcome

### 3. VERIFY (After each action)
- Did it work?
- Expected outcome achieved?
- Side effects?
- Time within budget?

### 4. DECIDE (Loop or Exit)
- Continue if: task relevant, within limits, no issues
- Stop if: done, blocked, time limit, user request

## Self-Correction Triggers

**Stop and ask when:**
- User explicitly requests stop
- Repeated failure (3x same action)
- New error not seen before
- Side effects detected
- User priority shift

**Self-correct silently:**
- Typo in command
- Minor environmental change
- Known fix available

## Logging

```markdown
# Autonomous Loop Log: YYYY-MM-DD HH:MM

**Task:** [what to accomplish]
**Goal:** [end state]
**Start:** HH:MM
**Interval:** [N minutes]

## Actions Taken
| Time | Action | Result |
|------|--------|--------|
| HH:MM | Did X | Success |
| HH:MM | Did Y | Failed, retried |
| HH:MM | Did Z | Success |

## Issues
- [Issue 1] → [Resolution]
- [Issue 2] → [Resolution]

## Final State
[What was accomplished]
**Duration:** HH:MM
**Completed:** Yes/No
```

## Constraints
- Never act without verification step
- Max 50 iterations before reporting
- Stop immediately on user interrupt
- Log everything for debugging
- Ask if unclear on 3rd failure
- Respect resource limits

## Safety
- Actions reversible when possible
- Keep audit trail
- Never delete data without warning
- Confirm destructive operations
- Stay within scope

## Output
Running: "🤖 [action] → [result]"
Done: "Completed: [summary]"
Blocked: "Blocked: [reason] - awaiting guidance"
